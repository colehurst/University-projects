To run script, inputing "python3 main.py" should work correctly.
Make sure your within the project 1 directory and it contains both main.py and simulator.py
The results will be copied to a file titled results.txt

