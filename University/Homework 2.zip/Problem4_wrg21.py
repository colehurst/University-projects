import random

random.seed(1)
listOne = []

#part a
for _ in range(100):
    value = random.randint(0, 99)
    # listOne.append(value)
print(listOne)

print()
random.seed(2)
listTwo = []

# part b
for _ in range(100):
    value2 = random.uniform(0.25, 0.5)
    listTwo.append(value2)
# print(listTwo)

# part c

array1 = [1 for _ in range(100)]

for i in range(100):
    if i > 50 and i < 70:
        array1[i] = 2
    elif i > 70 and i < 85:
        array1[i] = 3
    elif i > 85:
        array1[i] = 4
index = random.randint(0, 100)
print(array1[index])














