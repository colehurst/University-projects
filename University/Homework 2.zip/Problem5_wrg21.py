import math
import random

def power(k):
    n = 1
    for i in range(1, k):
        n = 3 * n
        return n
def fact(n):
    fact = 1
    for i in range(1,n):
        fact =fact*i
    return fact
sum = 0.0
averageArrivalRate = 0.0
averageServiceRate = 0.0
for processId in range(1,1000):
    x = random.uniform(0, 2 * processId)
    arrivalRate = random.uniform(0, 2)
    serviceRate = (math.exp(-1 * x))
    averageArrivalRate += arrivalRate
    averageServiceRate += serviceRate
    print(serviceRate, arrivalRate, processId)

averageArrivalRate = averageArrivalRate / 1000
averageServiceRate = averageServiceRate / 1000
print(averageServiceRate)
print(averageArrivalRate)

def getRandom(j):
    random.random()


