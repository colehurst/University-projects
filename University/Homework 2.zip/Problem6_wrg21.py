import math
import random

#part a
def simulation():
    for r in range(1, 20*365*24):
        x = random.randint(0, 500)
        firstFailure = (math.exp(10 * -x))
        firstRestoration = firstFailure + 10
        y = random.randint(0, 500)
        secondFailure = (math.exp(10 * -y))
        secondRestoration = secondFailure + 10
        print(firstRestoration, firstFailure)
        print(secondRestoration, secondFailure)
        if math.fabs(firstFailure - secondFailure) > 10:
            return
    return 20*365*24

#part b
def computeaverage(n):
    average = 0.0
    for _ in range(1, n):
        average += simulation()
    average /= n
    print(average)
computeaverage(101)




