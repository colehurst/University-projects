//Cole Hurst
#include <iostream>
#include "IntStack.h"
using namespace std;

IntStack :: IntStack()
{
    head = NULL;
}

IntStack :: ~IntStack()
{

}

void IntStack :: push(int)
{

}

int IntStack :: pop()
{

}

bool IntStack :: isFull()
{

}

bool IntStack :: isEmpty()
{
    if (head = NULL)
        return true;
    else
        return false;
}
