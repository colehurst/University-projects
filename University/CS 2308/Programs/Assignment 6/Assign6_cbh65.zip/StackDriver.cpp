/****************************************************
File Name: assign6_cbh65.cpp

Author: Cole Hurst
Date: 4.30.2018
Assignment Number: 6
CS 2308.262 Spring 2018
Lecture Instructor: Yijuan Lu


This program reads in a file that is asked by the user to be evaluated,
then it is read through to make sure it has matching (),{},[]. IF not an
error message will be read back to the user.
*****************************************************/
using namespace std;
#include <iostream>
#include <fstream>
#include <sstream>
#include "IntStack.cpp"
int main()
{
    ifstream inFile;
    string Filename;
    cout << "Please enter a file name: ";
    cin >> Filename;
}
