
import java.util.*;

/**
 * 
 */
public class Account Management {

    /**
     * Default constructor
     */
    public Account Management() {
    }

    /**
     * 
     */
    private float income;

    /**
     * 
     */
    private float expenses;

    /**
     * 
     */
    private float profit;

    /**
     * 
     */
    private String financeDoc;

    /**
     * 
     */
    private String cashFlow;

    /**
     * 
     */
    private String invoices;

    /**
     * 
     */
    public void print() {
        // TODO implement here
    }

    /**
     * 
     */
    public void updateNumbers() {
        // TODO implement here
    }

}