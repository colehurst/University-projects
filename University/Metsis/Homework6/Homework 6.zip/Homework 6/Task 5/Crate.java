
import java.util.*;

/**
 * 
 */
public class Crate extends Package {

    /**
     * Default constructor
     */
    public Crate() {
    }

    /**
     * 
     */
    private float lbMaxLoadWeight;

    /**
     * 
     */
    private String contnet;

    /**
     * 
     */
    public void getMaterial() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setMaterial() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getDiameter() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setDiameter() {
        // TODO implement here
    }

}