
import java.util.*;

/**
 * 
 */
public class Shipping Store Website extends Customer {

    /**
     * Default constructor
     */
    public Shipping Store Website() {
    }

    /**
     * 
     */
    private String packageLocation;

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void Attribute2;

    /**
     * 
     */
    public void contactStore() {
        // TODO implement here
    }

    /**
     * 
     */
    public void trackPackage() {
        // TODO implement here
    }

}