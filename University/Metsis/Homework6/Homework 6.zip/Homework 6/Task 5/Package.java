
import java.util.*;

/**
 * 
 */
public class Package {

    /**
     * Default constructor
     */
    public Package() {
    }

    /**
     * 
     */
    private String trackingNumber;

    /**
     * 
     */
    private String specifications;

    /**
     * 
     */
    private String mailingAdress;

    /**
     * 
     */
    private String location;

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void Role1;

    /**
     * 
     */
    public void Role2;

    /**
     * 
     */
    public void Role3;

    /**
     * 
     */
    public void getTrackingNumber() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setTrackingNumber() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getSpecifications() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getMailingAdress() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setMailingAdress() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getLocation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setLocation() {
        // TODO implement here
    }

}