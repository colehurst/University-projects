
import java.util.*;

/**
 * 
 */
public class Administrators extends Shipping Store Website {

    /**
     * Default constructor
     */
    public Administrators() {
    }

    /**
     * 
     */
    private String admin;


    /**
     * 
     */
    public void addEmployee() {
        // TODO implement here
    }

    /**
     * 
     */
    public void editEmployee() {
        // TODO implement here
    }

    /**
     * 
     */
    public void addAdmin() {
        // TODO implement here
    }

    /**
     * 
     */
    public void editAdmin() {
        // TODO implement here
    }

}