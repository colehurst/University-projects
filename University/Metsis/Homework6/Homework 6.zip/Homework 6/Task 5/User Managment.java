
import java.util.*;

/**
 * 
 */
public class User Managment extends Shipping Store Website {

    /**
     * Default constructor
     */
    public User Managment() {
    }

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private int phoneNumber;

    /**
     * 
     */
    private String email;

}