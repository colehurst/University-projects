
import java.util.*;

/**
 * 
 */
public class Customer {

    /**
     * Default constructor
     */
    public Customer() {
    }

    /**
     * 
     */
    private String address;

    /**
     * 
     */
    private int customerID;

    /**
     * 
     */
    public void register() {
        // TODO implement here
    }

    /**
     * 
     */
    public void login() {
        // TODO implement here
    }

    /**
     * 
     */
    public void editProfile() {
        // TODO implement here
    }

}