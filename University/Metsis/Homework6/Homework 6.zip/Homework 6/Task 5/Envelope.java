
import java.util.*;

/**
 * 
 */
public class Envelope extends Package {

    /**
     * Default constructor
     */
    public Envelope() {
    }

    /**
     * 
     */
    public void Port1;

    /**
     * 
     */
    public int inchHeight;

    /**
     * 
     */
    private int inchHeight;

    /**
     * 
     */
    private void inchWidth int;

    /**
     * 
     */
    public void getHeight() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setHeight() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getWidth() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setWidth() {
        // TODO implement here
    }

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

}