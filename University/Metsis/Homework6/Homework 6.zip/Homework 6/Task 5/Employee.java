
import java.util.*;

/**
 * 
 */
public class Employee {

    /**
     * Default constructor
     */
    public Employee() {
    }

    /**
     * 
     */
    private int socialSN;

    /**
     * 
     */
    private flaot monthlySalary;

    /**
     * 
     */
    private int bankAccountNum;

    /**
     * 
     */
    private boolean activity;

    /**
     * 
     */
    private int employeeID;

    /**
     * 
     */
    public void Attribute1;


    /**
     * 
     */
    public void getActivity() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setActivity() {
        // TODO implement here
    }

    /**
     * 
     */
    public void respondForm() {
        // TODO implement here
    }

}