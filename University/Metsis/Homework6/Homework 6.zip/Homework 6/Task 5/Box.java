
import java.util.*;

/**
 * 
 */
public class Box extends Package {

    /**
     * Default constructor
     */
    public Box() {
    }

    /**
     * 
     */
    private int inchLinear;

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void getLinear() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setLinear() {
        // TODO implement here
    }

}