
import java.util.*;

/**
 * 
 */
public class Transaction Managment extends Employee {

    /**
     * Default constructor
     */
    public Transaction Managment() {
    }

    /**
     * 
     */
    private String status;

    /**
     * 
     */
    private int dateCreated;

    /**
     * 
     */
    private int shippingCost;

    /**
     * 
     */
    private int dateDelivered;

    /**
     * 
     */
    private String pickDropStatus;

    /**
     * 
     */
    private String employeeDeliverd;

    /**
     * 
     */
    public void Attribute1;


    /**
     * 
     */
    public void createTransaction() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setStatus() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setShippingCost() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setDates() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setPickDropStatus() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setEmployeeDelivery() {
        // TODO implement here
    }

}