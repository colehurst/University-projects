
import java.util.*;

/**
 * 
 */
public class Drum extends Package {

    /**
     * Default constructor
     */
    public Drum() {
    }

    /**
     * 
     */
    private String material;

    /**
     * 
     */
    private float inchDiameter;

    /**
     * 
     */
    public void Attribute1;

    /**
     * 
     */
    public void getMaterial() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setMaterial() {
        // TODO implement here
    }

    /**
     * 
     */
    public void getDiameter() {
        // TODO implement here
    }

    /**
     * 
     */
    public void setDiameter() {
        // TODO implement here
    }

}