// Assignment I2: Due June 18
// Written by: Cole Hurst (cbh65)
// GUI Summer session 1, Dr. Dan Tamir
// main.cpp


#include <QApplication>
#include "mainMenu.h"
#include "mainMenu.cpp"


int main(int argc, char *argv[]) {

    QApplication app(argc, argv);

    // main and menu window
    mainMenu window;

    window.resize(1000, 350);
    window.setWindowTitle("Boat Sim");
    window.show();

    return app.exec();
}
