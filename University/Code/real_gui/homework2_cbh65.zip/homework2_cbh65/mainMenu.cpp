// Assignment I2: Due June 18
// Written by: Cole Hurst (cbh65)
// GUI Summer session 1, Dr. Dan Tamir
// mainMenu.cpp


#include "mainMenu.h"
#include <QWidget>
#include <QApplication>
#include <QSlider>
#include <QSpinBox>
#include <QDial>
#include <QLCDNumber>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QRadioButton>
#include <QLabel>
#include <QPushButton>
#include <QMainWindow>
#include <QMenu>
#include <QMenuBar>
#include <QMainWindow>
#include <QStatusBar>
#include <QAction>
#include <QTextEdit>
#include <QWidget>
#include <QHeaderView>
#include <QToolBar>
#include <QCoreApplication>
#include <QKeySequence>
#include <QtGui>
#include <QObject>
#include <QComboBox>
#include <QMessageBox>
#include <QMouseEvent>
#include <QApplication>

mainMenu::mainMenu(QWidget *parent)
: QMainWindow(parent) {


    // declaring widgets
    QSpinBox *spinBox = new QSpinBox;
    QSlider *slider = new QSlider(Qt::Horizontal);
    QSpinBox *maxTicsSpinBox = new QSpinBox;
    QSlider *maxTicsSlider = new QSlider(Qt::Horizontal);
    QDial *dial = new QDial;
    QLCDNumber *lcd = new QLCDNumber;
    QLCDNumber *lcdtoo = new QLCDNumber;
    QRadioButton *x = new QRadioButton("X");
    QRadioButton *y = new QRadioButton("Y");
    QRadioButton *z = new QRadioButton("Z");
    QLabel *comboBoxLabel = new QLabel("Select an option");
    QLabel *gridSize = new QLabel("Grid Size (N * N)");
    QLabel *maxNumTicksLabel = new QLabel("Max. # of Tics");
    QSpinBox *boatX_X = new QSpinBox;
    QSpinBox *boatX_Y = new QSpinBox;
    QSpinBox *boatY_X = new QSpinBox;
    QSpinBox *boatY_Y = new QSpinBox;
    QSpinBox *boatZ_X = new QSpinBox;
    QSpinBox *boatZ_Y = new QSpinBox;
    QLabel *simulationDuration = new QLabel("Simulation Duration");
    simulationDuration->setBuddy(lcd);
    QLabel *clickCounter = new QLabel("Click Counter");
    QLabel *x_xCoor = new QLabel("X : X-Coor");
    QLabel *x_yCoor = new QLabel("X : Y-Coor");
    QLabel *y_xCoor = new QLabel("Y : X-Coor");
    QLabel *y_yCoor = new QLabel("Y : Y-Coor");
    QLabel *z_xCoor = new QLabel("Z : X-Coor");
    QLabel *z_yCoor = new QLabel("Z : Y-Coor");
    QLabel *boatSelect = new QLabel("Boat Selection");
    QLabel *boatActionSelect = new QLabel("Boat Action Selection");
    QLabel *exitConditionSelect = new QLabel("Termination Condition");
    QComboBox *boatActionComboBox = new QComboBox;
    boatActionComboBox->addItem("Follow");
    boatActionComboBox->addItem("Chase");
    boatActionComboBox->addItem("Circle");
    QComboBox *exitConditionComboBox = new QComboBox;
    exitConditionComboBox->addItem("Boat Y is “close” to boat X, spec. in Euclidean pixels");
    exitConditionComboBox->addItem("Boat Y is close to boat Z");
    exitConditionComboBox->addItem("Boat Y is in subregion A");
    QPushButton *exitButton = new QPushButton("QUIT");

    QTextEdit *textEdit = new QTextEdit;
    QLabel *textEditArea = new QLabel("Text Edit Area");

    boatSelect->setBuddy(x);

    // menu bar
    createActions();
    createMenus();

    QString message = tr("A context menu is available by right-clicking");
    statusBar()->showMessage(message);

    setWindowTitle(tr("Menus"));
    setMinimumSize(160, 160);
    resize(480, 320);

    QObject::connect(boatActionComboBox, SIGNAL(currentIndexChanged(QString)), comboBoxLabel, SLOT(setText(QString)));
    QObject::connect(exitConditionComboBox, SIGNAL(currentIndexChanged(QString)), comboBoxLabel, SLOT(setText(QString)));

    // Left side Spinboxes / Sliders
    spinBox->setRange(100, 2000);
    slider->setRange(100, 2000);
    spinBox->setValue(1000);
    gridSize->setBuddy(slider);

    QObject::connect(spinBox, SIGNAL(valueChanged(int)), slider, SLOT(setValue(int)));
    QObject::connect(slider, SIGNAL(valueChanged(int)), spinBox, SLOT(setValue(int)));

    maxTicsSpinBox->setRange(100, 2000);
    maxTicsSlider->setRange(100, 2000);
    maxTicsSpinBox->setValue(1000);
    maxNumTicksLabel->setBuddy(maxTicsSlider);

    QObject::connect(maxTicsSpinBox, SIGNAL(valueChanged(int)), maxTicsSlider, SLOT(setValue(int)));
    QObject::connect(maxTicsSlider, SIGNAL(valueChanged(int)), maxTicsSpinBox, SLOT(setValue(int)));

    // Middle Boat Coordinate Constraints
    boatX_X->setRange(-1, 1000);
    boatX_X->setValue(-1);
    boatX_Y->setRange(-1, 1000);
    boatX_Y->setValue(-1);

    boatY_X->setRange(-1, 1000);
    boatY_X->setValue(-1);
    boatY_Y->setRange(-1, 1000);
    boatY_Y->setValue(-1);

    boatZ_X->setRange(-1, 1000);
    boatZ_X->setValue(-1);
    boatZ_Y->setRange(-1, 1000);
    boatZ_Y->setValue(-1);

    QObject::connect(boatX_Y, SIGNAL(valueChanged(int)), boatX_Y, SLOT(setValue(int)));

    // connecting volume dial to lcd
    dial->setRange(0, 1000);
    QObject::connect(dial, SIGNAL(valueChanged(int)), lcd , SLOT(display(int)));

    // layouts
    QVBoxLayout *farRightLayout = new QVBoxLayout;
    farRightLayout->addWidget(textEditArea);
    farRightLayout->addWidget(textEdit);
    farRightLayout->addWidget(clickCounter);
    farRightLayout->addWidget(lcdtoo);

    QVBoxLayout *leftLayout = new QVBoxLayout;
    leftLayout ->addWidget(boatSelect);
    leftLayout->addWidget(x);
    leftLayout->addWidget(y);
    leftLayout->addWidget(z);
    leftLayout ->addWidget(boatActionSelect);
    leftLayout ->addWidget(boatActionComboBox);
    leftLayout->addWidget(gridSize);
    leftLayout->addWidget(spinBox);
    leftLayout->addWidget(slider);
    leftLayout->addWidget(maxNumTicksLabel);
    leftLayout->addWidget(maxTicsSpinBox);
    leftLayout->addWidget(maxTicsSlider);

    QVBoxLayout *middleLayout = new QVBoxLayout;
    middleLayout->addWidget(simulationDuration);
    middleLayout->addWidget(dial);
    middleLayout->addWidget(lcd);
    middleLayout->addWidget(exitConditionSelect);
    middleLayout->addWidget(exitConditionComboBox);
    middleLayout->addWidget(exitButton);

    QVBoxLayout *rightLayout = new QVBoxLayout;
    rightLayout->addWidget(x_xCoor);
    rightLayout->addWidget(boatX_X);
    rightLayout->addWidget(x_yCoor);
    rightLayout->addWidget(boatX_Y);
    rightLayout->addWidget(y_xCoor);
    rightLayout->addWidget(boatY_X);
    rightLayout->addWidget(y_yCoor);
    rightLayout->addWidget(boatY_Y);
    rightLayout->addWidget(z_xCoor);
    rightLayout->addWidget(boatZ_X);
    rightLayout->addWidget(z_yCoor);
    rightLayout->addWidget(boatZ_Y);

    QHBoxLayout *layout = new QHBoxLayout;
    layout->addLayout(leftLayout);
    layout->addLayout(middleLayout);
    layout->addLayout(rightLayout);
    layout->addLayout(farRightLayout);



    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    centralWidget->setLayout(layout);

}

void mainMenu::open()
{
    infoLabel->setText(tr("Invoked <b>File|Open</b>"));
}

void mainMenu::save()
{
    infoLabel->setText(tr("Invoked <b>File|Save</b>"));
}

void mainMenu::quit()
{
    infoLabel->setText(tr("Invoked <b>Quit|Quit application</b>"));

}

void mainMenu::about()
{
    infoLabel->setText(tr("Invoked <b>Help|About</b>"));
    QMessageBox::about(this, tr("About Menu"),
                       tr("The <b>Menu</b> example shows how to create "
                          "menu-bar menus and context menus."));
}

void mainMenu::aboutQt()
{
    infoLabel->setText(tr("Invoked <b>Help|About Qt</b>"));
}




void mainMenu::createActions()
{
    openAct = new QAction(tr("&Open"), this);
    openAct->setShortcuts(QKeySequence::Open);
    openAct->setStatusTip(tr("Open an existing file"));
    connect(openAct, SIGNAL(triggered()), this, SLOT(open()));

    saveAct = new QAction(tr("&Save"), this);
    saveAct->setShortcuts(QKeySequence::Save);
    saveAct->setStatusTip(tr("Save the document to disk"));
    connect(saveAct, SIGNAL(triggered()), this, SLOT(save()));


    aboutAct = new QAction(tr("&About"), this);
    aboutAct->setStatusTip(tr("Show the application's About box"));
    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));

    aboutQtAct = new QAction(tr("About &Qt"), this);
    aboutQtAct->setStatusTip(tr("Show the Qt library's About box"));
    connect(aboutQtAct, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
    connect(aboutQtAct, SIGNAL(triggered()), this, SLOT(aboutQt()));


    quitAct = new QAction(tr("&Quit application"), this);
    quitAct->setShortcuts(QKeySequence::Quit);
    quitAct->setStatusTip(tr("Exit the application"));
    connect(quitAct, SIGNAL(triggered()), this, SLOT(close()));
    //QObject::connect(quit, SIGNAL(triggered()), QApplication::instance(), SLOT(quit()));

}



void mainMenu::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);

    helpMenu = menuBar()->addMenu(tr("&Help"));
    helpMenu->addAction(aboutAct);
    helpMenu->addAction(aboutQtAct);

    QuitMenu = menuBar()->addMenu(tr("&Quit"));
    QuitMenu->addAction(quitAct);

}


