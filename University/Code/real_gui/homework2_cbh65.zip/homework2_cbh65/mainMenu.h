// Assignment I2: Due June 18
// Written by: Cole Hurst (cbh65)
// GUI Summer session 1, Dr. Dan Tamir
// mainMenu.h



#pragma once

#include <QMainWindow>
#include <QApplication>
#include <QObject>
#include <QSettings>

class QAction;
class QMenu;
class QLabel;

class mainMenu : public QMainWindow {

    Q_OBJECT

public:
   mainMenu(QWidget *parent = 0);

private slots:
    void open();
    void save();
    void quit();
    void about();
    void aboutQt();

private:
    void createActions();
    void createMenus();


    QMenu *fileMenu;
    QMenu *helpMenu;
    QMenu *QuitMenu;
    QAction *openAct;
    QAction *saveAct;
    QAction *quitAct;
    QAction *aboutAct;
    QAction *aboutQtAct;
    QLabel *infoLabel;
    QSettings *settings;
};



