// Assignment I1: Due June 18
// Written by: Cole Hurst (cbh65)
// GUI Summer session 1, Dr. Dan Tamir
// mainMenu.h



#pragma once

#include <QMainWindow>
#include <QApplication>
#include <QObject>
#include <QSettings>

class QAction;
class QMenu;
class QLabel;

class mainWindow : public QMainWindow {

    Q_OBJECT

public:
   mainWindow(QWidget *parent = 0);

};
